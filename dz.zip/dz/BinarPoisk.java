package dz;

import java.util.Scanner;

public class BinarPoisk {
    static void Chislo(int[] numbers) {
        Scanner scan = new Scanner(System.in);
        int SearchNum = scan.nextInt();
        int firstindex = 0;
        int index = -1;
        int lastindex = numbers.length - 1;
        while (firstindex <= lastindex) {
            int middleIndex = (firstindex + lastindex) / 2;
            if (SearchNum > numbers[middleIndex]) {
                firstindex = middleIndex + 1;
            } else if (SearchNum < numbers[middleIndex]) {
                lastindex = middleIndex - 1;
            } else {
                index = middleIndex;
                break;
            }
        }
        if (index >= 0) {
            System.out.println("Число найдено - индекс числа: " + index);
        }
        else {
            System.out.println("Число не найдено");
        }
    }
}
